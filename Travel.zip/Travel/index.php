<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <!-- custom css link -->
    <link rel="stylesheet" href="css\style.css">
    <!-- font awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- swiper css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>
    <!-- google font link -->

</head>
<body>

    
    <!-- header section -->
        <section class="header">
            <a href="index.php" class="logo">TRAVEL&nbsp;&nbsp;.</a>
                <nav class="navbar">
                    <a href="index.php">HOME</a>
                    <a href="about.php">ABOUT</a>
                    <a href="package.php">PACKAGE</a>
                    <a href="book.php">BOOK</a>
                </nav>
                <div id="menu-btn" class="fa fa-bars"></div>
        </section>

       











    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <!-- custom js file ink -->
    <script src="java scripts\javascript.js"></script>
</body>
</html>